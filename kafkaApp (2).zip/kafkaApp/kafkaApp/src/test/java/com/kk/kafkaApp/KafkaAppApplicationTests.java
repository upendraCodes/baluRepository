package com.kk.kafkaApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
