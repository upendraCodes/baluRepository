package com.kk.kafkaApp.producer;

import org.apache.logging.log4j.LogManager;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
@Service
public class KafkaProducer {
	
	private static final Logger log=LogManager.getLogger(KafkaProducer.class);
	
	//@Value("${spring.kafka.topicname}")
//	private String topicname;
	
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	
	public void sendMessage(String msg) {
		log.info("Kafka producer sending messeges as === "+msg);
		kafkaTemplate.send("MyFirstKafka", msg);
	}
	
}
